<?php
    $empfaenger = "Your@E-Mail.com";  // Please enter your email address here. (between the inverted comma)
    $ihrname = "Your Name"; // Please enter your name here. (between the inverted comma) It will appear as consigner in the thank mail.
    
    
    $danke = "thankyou.php";  // URL to thank you page.
?> 